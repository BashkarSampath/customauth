package com.bashkarsampath.app.services.user;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bashkarsampath.app.entities.Role;
import com.bashkarsampath.app.entities.User;
import com.bashkarsampath.app.enums.Provider;
import com.bashkarsampath.app.repositories.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserService {
	@Autowired
	private UserRepository repo;

	public User getDbUserOauth2PostLogin(String username, boolean saveAsNewUser){
		Optional<User> optionalUser = repo.getUserByUsername(username);
		if (optionalUser.isPresent())
			return optionalUser.get();
		else {
			if (!saveAsNewUser)
				return null;
			else {
				User newUser = new User();
				newUser.setUsername(username);
				newUser.setProvider(Provider.GOOGLE);
				newUser.setEnabled(true);
				Role userRole = new Role();
				userRole.setName("ROLE_EMPLOYEE");
				newUser.setRoles(new HashSet<>(Arrays.asList(userRole)));
				newUser = repo.save(newUser);
				log.info("Created new user: " + username);
				return newUser;
			}
		}
	}
}