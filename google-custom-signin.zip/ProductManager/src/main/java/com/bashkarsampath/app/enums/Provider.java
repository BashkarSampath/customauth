package com.bashkarsampath.app.enums;

public enum Provider {
	GOOGLE
}
